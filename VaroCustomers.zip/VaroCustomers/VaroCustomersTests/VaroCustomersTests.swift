//
//  VaroCustomersTests.swift
//  VaroCustomers
//
//  Created on 7/14/21
//

import XCTest
import Combine
@testable import VaroCustomers

class VaroCustomersTests: XCTestCase {

    func testFindMinMaxYear() {
        let logEntry = [
            ("Raevon Taenmaereon", 2001, 2004),
            ("Daman Cantrill", 2002, 2005),
            ("Taenys Laerdaerys", 2010, 2012),
            ("Dorrick Qorgyle", 2005, 2009),
            ("Corrad Morshall", 2005, 2012)
        ]

        let maxYearMaxCount = findMaxYear(logEntry)

        XCTAssertEqual(maxYearMaxCount?.maxYear, 2005)
        XCTAssertEqual(maxYearMaxCount?.maxCount, 3)
    }
}
