
# Description

Consider a list that tracks when a customer opens or closes their Varo account. 
Find the year with the most customers with an active account.
Note that the log entries are not in any order.

# Example: 

## Input: 

| Name               | Start | End  |
|--------------------+-------+------|
| Raevon Taenmaereon | 2001  | 2004 |
| Daman Cantrill     | 2002  | 2005 |
| Taenys Laerdaerys  | 2010  | 2012 |
| Dorrick Qorgyle    | 2005  | 2009 |
| Corrad Morshall    | 2005  | 2012 |

## Output: 2005

There are a maximum of 3 customers with a Varo account in 2005

# Expectations

1. Create a function that receives the input list and returns the year with the most customers with an active account
2. Fetch this information asynchronously using the `fetchLog` utility function that is already provided
3. Create your own function to fetch the input from the following endpoint `https://215eight.github.io/VaroCustomers.csv`
4. Display the list of customers highlighting with a different color those with an active account in the year with active accounts. The list should include name, open and close year
5. Add a ui element to show all customers, only customers with an account in the year most active accounts 
