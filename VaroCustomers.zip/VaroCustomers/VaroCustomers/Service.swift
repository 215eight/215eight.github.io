//
//  Network.swift
//  VaroCustomers
//
//  Created on 7/14/21
//

import Foundation
import Combine

struct CustomError: Error {}

let serviceQueue = DispatchQueue.global()

func fetchLog() -> AnyPublisher<[(String, Int, Int)], Error> {
    mockFetchLog()
        .eraseToAnyPublisher()
}

func mockFetchLog() -> AnyPublisher<[(String, Int, Int)], Error> {
    Thread.sleep(forTimeInterval: 3.0)
    return Just([
        ("Raevon Taenmaereon", 2001, 2004),
        ("Daman Cantrill", 2002, 2005),
        ("Taenys Laerdaerys", 2010, 2012),
        ("Dorrick Qorgyle", 2005, 2009),
        ("Corrad Morshall", 2005, 2012)
    ])
    .setFailureType(to: Error.self)
    .eraseToAnyPublisher()
}
