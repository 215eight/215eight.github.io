//
//  VaroCustomersApp.swift
//  VaroCustomers
//
//  Created on 7/14/21
//

import SwiftUI

@main
struct VaroCustomersApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
