//
//  FAQZendeskApp.swift
//  Shared
//
//  Created by Akshay Dixit on 01/07/22.
//

import SwiftUI
import SupportProvidersSDK
//import ZendeskCoreSDK

import UIKit
//import SupportSDK
import ZendeskCoreSDK

@main
struct FAQZendeskApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(themeColor: UIColor.red)
        }
    }
}
