//
//  ContentView.swift
//  Shared
//
//  Created by Akshay Dixit on 01/07/22.
//

import SwiftUI
import SupportProvidersSDK
//import ZendeskCoreSDK

import UIKit
//import SupportSDK
import ZendeskCoreSDK

struct ContentView: View {
    let themeColor: UIColor
    
    var body: some View {
        NavigationView {
            VStack {
                Image("zendesk")
                    .resizable()
                    .frame(width: 250, height: 250)
                    .clipShape(Circle())
                Spacer()
                    .frame(width: 100, height: 20, alignment: .center)
                Text("SwiftUI Sample")
                Spacer()
                    .frame(width: 100, height: 20, alignment: .center)
                NavigationLink(destination: MessagingView(themeColor: themeColor)) {
                    Text("Redirect To FAQ")
                }
            }.padding(.bottom, 80)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(themeColor: .brown)
    }
}

