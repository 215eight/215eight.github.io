//
//  ZendeskMessaging.swift
//  UnifiedSDKSample
//
//  Created by Zendesk on 13/04/2020.
//  Copyright © 2020 Zendesk. All rights reserved.
//

import SwiftUI

import MessagingSDK // Messaging VC
import CommonUISDK // Styling
import UIKit
import ZendeskCoreSDK
import UIKit
import SupportSDK

struct MessagingView: View {
    let themeColor: UIColor

    var body: some View {
        MessagingController()
    }
}

struct MessagingController: UIViewControllerRepresentable {
    public init() {
        Zendesk.initialize(appId: "", clientId: "", zendeskUrl: "")
        Support.initialize(withZendesk: Zendesk.instance!)
    }
    
    var hcConfig: HelpCenterUiConfiguration {
        let hcConfig = HelpCenterUiConfiguration()
        hcConfig.showContactOptions = false
        return hcConfig
    }

    func updateMessagingStyling() {
        CommonTheme.currentTheme.primaryColor = UIColor.red
    }

    func makeUIViewController(context: UIViewControllerRepresentableContext<MessagingController>) -> UIViewController {
        HelpCenterUi.buildHelpCenterOverviewUi(withConfigs: [hcConfig])
    }
    
    public func updateUIViewController(_ uiViewController: UIViewController,
                                       context: UIViewControllerRepresentableContext<MessagingController>)
    {
        uiViewController.view.backgroundColor = UIColor.red
    }
}


